import React, { useRef, useContext, useEffect } from 'react';
import { CurrentUserContext } from '../contexts/CurrentUserContext';
import PopupWithForm from './PopupWithForm';

function EditAvatarPopup({ isOpen, onClose, onUpdateAvatar }) {
  const currentUser = useContext(CurrentUserContext);
  const avatarInput = useRef();

  function handleSubmit(e) {
    e.preventDefault();

    onUpdateAvatar({
      avatar: avatarInput.current.value,
    });
  }

  useEffect(() => {
    avatarInput.current.value = currentUser.avatar;
  }, [currentUser]);


  return (
    <PopupWithForm
      name="avatar"
      title="Обновить аватар"
      submitText="Сохранить"
      isOpen={isOpen}
      onClose={onClose}
      onSubmit={handleSubmit}
    >
      <input 
        id ='profile-avatar' 
        className="popup__input popup__input_profile_avatar"  
        name="link" 
        type="url" 
        placeholder="Ссылка на картинку" 
        ref={avatarInput} 
        required/>
      <span id="profile-avatar-error" className="popup__error"/>
    </PopupWithForm>

  )
}

export default EditAvatarPopup;
